import os
import django
import sys
import re

# Add the project directory to the path
sys.path.append('/Users/copv/Data/code/nails_salon')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nails_salon_project.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

# Create test client
client = Client()

# Login as existing user 
client.login(username='test', password='test123')

# Test GET /book/ 
response = client.get('/book/')
html_content = response.content.decode()

# Extract debug comments
debug_pattern = r'<!-- DEBUG: (.+?) -->'
debug_matches = re.findall(debug_pattern, html_content)

print("=== DEBUG COMMENTS FROM HTML ===")
for debug in debug_matches:
    print(f"DEBUG: {debug}")

print("\n=== CHECKING REGROUP ISSUE ===")
# Check if we can find services in HTML
if 'category-group' in html_content:
    print("✅ Found category-group divs in HTML")
else:
    print("❌ No category-group divs found - regroup failed!")

# Check services in HTML
service_pattern = r'service_(\d+)'
service_matches = re.findall(service_pattern, html_content)
print(f"Services found in HTML: {len(service_matches)}")

if 'Keine Services verfügbar' in html_content and len(service_matches) == 0:
    print("❌ CONFIRMED: regroup by category returns empty list")
    print("This means services.queryset has services but regroup by category fails")