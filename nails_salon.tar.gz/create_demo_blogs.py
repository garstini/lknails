#!/usr/bin/env python
import os
import sys
import django

# Setup Django
sys.path.append('/Users/copv/Data/code/nails_salon')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nails_salon_project.settings')
django.setup()

from salon.models import BlogPost, ServiceCategory
from django.contrib.auth import get_user_model
User = get_user_model()

def create_demo_blogs():
    # Tạo user admin nếu chưa có
    admin_user, created = User.objects.get_or_create(
        username='admin', 
        defaults={
            'email': 'admin@lknails.de', 
            'is_staff': True, 
            'is_superuser': True,
            'first_name': 'Admin',
            'last_name': 'User'
        }
    )
    if created:
        admin_user.set_password('admin123')
        admin_user.save()
        print('Admin user created')

    # Sử dụng ServiceCategory thay vì Category riêng
    blog_category, created = ServiceCategory.objects.get_or_create(
        name='Blog', 
        defaults={'description': 'Blog articles and news'}
    )
    if created:
        print('Blog category created')

    # Tạo demo blog posts
    demo_posts = [
        {
            'title': 'Die neuesten Trends in der Nagelkunst 2024',
            'slug': 'nail-art-trends-2024',
            'summary': 'Entdecken Sie die angesagtesten Nageltrends für 2024 - von minimalistischen Designs bis zu extravaganten Nail Art Kreationen.',
            'content': '''<h2>Die Top 5 Nageltrends 2024</h2>

<p>Das Jahr 2024 bringt aufregende neue Trends in der Nagelkunst. Bei <strong>LK Nails & Lashes</strong> sind wir immer am Puls der Zeit und bieten Ihnen die neuesten Designs.</p>

<h3>1. Minimalistischer Chic</h3>
<p>Weniger ist mehr - dieser Trend setzt auf <em>schlichte Eleganz</em> mit:</p>
<ul>
    <li>Nude- und Pastelltöne</li>
    <li>Feine goldene Akzente</li>
    <li>Geometrische Linien</li>
</ul>

<h3>2. French Manicure Reloaded</h3>
<p>Die klassische French Manicure erlebt ein <strong>Revival</strong> mit modernen Twists:</p>
<blockquote>
    <p>"Die neue French Manicure ist vielseitiger und kreativer als je zuvor" - Unser Nail Art Team</p>
</blockquote>

<h3>3. Holografische Effekte</h3>
<p>Schillernde, holografische Lacke sorgen für einen <em>futuristischen Look</em> der garantiert alle Blicke auf sich zieht.</p>

<h3>4. Mix & Match</h3>
<p>Verschiedene Designs pro Finger sind absolut im Trend. Kombinieren Sie:</p>
<ol>
    <li>Verschiedene Farben</li>
    <li>Unterschiedliche Texturen</li>
    <li>Matte und glänzende Oberflächen</li>
</ol>

<p><a href="/services/" class="btn btn-primary">Jetzt Termin buchen</a></p>''',
            'is_featured': True
        },
        {
            'title': 'Nagelpflege im Winter - Tipps für gesunde Nägel',
            'slug': 'nagelpflege-winter-tipps',
            'summary': 'Die kalte Jahreszeit stellt unsere Nägel vor besondere Herausforderungen. Hier sind unsere Profi-Tipps für gesunde Nägel im Winter.',
            'content': '''<h2>Warum brauchen Nägel im Winter besondere Pflege?</h2>

<p>Die <strong>kalte Winterluft</strong> und trockene Heizungsluft entziehen unseren Nägeln wichtige Feuchtigkeit. Das Ergebnis: brüchige, splitternde Nägel.</p>

<div class="alert alert-info">
    <h4>💡 Profi-Tipp</h4>
    <p>Tragen Sie immer Handschuhe beim Schneeschaufeln oder längeren Aufenthalten in der Kälte!</p>
</div>

<h3>Die wichtigsten Pflegetipps:</h3>

<h4>1. Regelmäßige Feuchtigkeitspflege</h4>
<p>Verwenden Sie täglich eine <em>nährende Nagelcreme</em> oder Nagelhautöl:</p>
<ul>
    <li>Morgens nach dem Händewaschen</li>
    <li>Abends vor dem Schlafengehen</li>
    <li>Nach jedem Kontakt mit Wasser</li>
</ul>

<h4>2. Schutz vor Kälte</h4>
<blockquote>
    <p>"Handschuhe sind der beste Freund Ihrer Nägel im Winter" - LK Nails Team</p>
</blockquote>

<h4>3. Die richtige Ernährung</h4>
<p>Stärken Sie Ihre Nägel von innen mit:</p>
<table class="table table-striped">
    <tr>
        <th>Nährstoff</th>
        <th>Wirkung</th>
        <th>Quellen</th>
    </tr>
    <tr>
        <td>Biotin</td>
        <td>Stärkt die Nagelstruktur</td>
        <td>Eier, Nüsse, Hülsenfrüchte</td>
    </tr>
    <tr>
        <td>Zink</td>
        <td>Fördert das Nagelwachstum</td>
        <td>Fleisch, Kürbiskerne, Haferflocken</td>
    </tr>
    <tr>
        <td>Eisen</td>
        <td>Verhindert brüchige Nägel</td>
        <td>Spinat, Linsen, dunkles Fleisch</td>
    </tr>
</table>

<h3>Professionelle Winterpflege</h3>
<p>Gönnen Sie sich regelmäßig eine <strong>professionelle Maniküre</strong> in unserem Studio. Wir bieten spezielle Winterbehandlungen an.</p>

<p><em>Tipp:</em> Buchen Sie alle 3-4 Wochen eine Maniküre für optimal gepflegte Nägel.</p>''',
            'is_featured': False
        },
        {
            'title': 'Gel-Nägel vs. Acryl-Nägel - Der ultimative Vergleich',
            'slug': 'gel-vs-acryl-naegel-vergleich',
            'summary': 'Gel oder Acryl? Wir erklären die Unterschiede und helfen Ihnen bei der Entscheidung für die richtige Nagelverlängerung.',
            'content': '''<h2>Der große Vergleich: Gel vs. Acryl</h2>

<p>Bei der Nagelverlängerung stehen Sie oft vor der Wahl: <strong>Gel-Nägel</strong> oder <strong>Acryl-Nägel</strong>? Beide Methoden haben ihre Vor- und Nachteile.</p>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h3>💎 Gel-Nägel</h3>
            </div>
            <div class="card-body">
                <h4>Vorteile:</h4>
                <ul>
                    <li>Natürlicher Look</li>
                    <li>Flexibel und bruchresistent</li>
                    <li>Keine starken Dämpfe</li>
                    <li>Einfache Entfernung</li>
                </ul>
                
                <h4>Nachteile:</h4>
                <ul>
                    <li>Weniger stabil als Acryl</li>
                    <li>UV-Licht zum Aushärten nötig</li>
                    <li>Höhere Kosten</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-secondary text-white">
                <h3>💪 Acryl-Nägel</h3>
            </div>
            <div class="card-body">
                <h4>Vorteile:</h4>
                <ul>
                    <li>Sehr stabil und haltbar</li>
                    <li>Günstigerer Preis</li>
                    <li>Kein UV-Licht nötig</li>
                    <li>Lange Haltbarkeit</li>
                </ul>
                
                <h4>Nachteile:</h4>
                <ul>
                    <li>Starke Dämpfe während Behandlung</li>
                    <li>Schwieriger zu entfernen</li>
                    <li>Weniger natürlich</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<h3>Für wen eignet sich was?</h3>

<h4>🌟 Gel-Nägel sind perfekt für Sie, wenn:</h4>
<ul>
    <li>Sie einen <em>natürlichen Look</em> bevorzugen</li>
    <li>Sie empfindlich auf chemische Dämpfe reagieren</li>
    <li>Sie flexibel im Beruf arbeiten</li>
    <li>Sie bereit sind, mehr zu investieren</li>
</ul>

<h4>💎 Acryl-Nägel sind ideal, wenn:</h4>
<ul>
    <li>Sie sehr <strong>stabile Nägel</strong> brauchen</li>
    <li>Sie körperlich arbeiten</li>
    <li>Sie ein begrenztes Budget haben</li>
    <li>Sie lange Nägel möchten</li>
</ul>

<blockquote class="blockquote">
    <p>"Die Wahl zwischen Gel und Acryl hängt von Ihrem Lifestyle und Ihren Bedürfnissen ab. Lassen Sie sich von uns beraten!"</p>
    <footer class="blockquote-footer">Das LK Nails Team</footer>
</blockquote>

<h3>Pflege-Tipps für beide Varianten</h3>

<div class="alert alert-success">
    <h4>✨ Universelle Pflege-Tipps</h4>
    <ol>
        <li><strong>Handschuhe</strong> bei Hausarbeit tragen</li>
        <li>Regelmäßige <em>Nachbehandlung</em> alle 2-3 Wochen</li>
        <li><strong>Nagelhautpflege</strong> nicht vergessen</li>
        <li>Vorsicht bei der <em>Nagelhautentfernung</em></li>
    </ol>
</div>

<p>Unser erfahrenes Team berät Sie gerne bei der Wahl der richtigen Methode. <a href="/contact/" class="btn btn-outline-primary">Beratungstermin vereinbaren</a></p>''',
            'is_featured': True
        },
        {
            'title': 'Lash Extensions - Alles was Sie wissen müssen',
            'slug': 'lash-extensions-guide',
            'summary': 'Von klassisch bis Volumen - hier finden Sie alle wichtigen Informationen zu Wimpernverlängerungen und deren Pflege.',
            'content': '''<h2>Was sind Lash Extensions?</h2>

<p><strong>Lash Extensions</strong> sind eine professionelle Methode zur Verlängerung und Verdichtung der natürlichen Wimpern. Einzelne Kunstwimpern werden präzise auf jede natürliche Wimper geklebt.</p>

<div class="alert alert-warning">
    <h4>⚠️ Wichtig</h4>
    <p>Lassen Sie Lash Extensions nur von geschulten Profis durchführen! Unsachgemäße Anwendung kann zu Schäden führen.</p>
</div>

<h3>Die verschiedenen Techniken</h3>

<h4>1. Classic Lashes</h4>
<p>Bei der <em>klassischen Methode</em> wird eine Kunstwimper auf eine natürliche Wimper geklebt:</p>
<ul>
    <li>Natürlicher Look</li>
    <li>Verlängert die eigenen Wimpern</li>
    <li>Ideal für Anfänger</li>
    <li>Haltbarkeit: 4-6 Wochen</li>
</ul>

<h4>2. Volume Lashes</h4>
<p>Mehrere dünne Kunstwimpern werden zu einem <strong>Fächer</strong> geformt:</p>
<ul>
    <li>Dramatischer, voller Look</li>
    <li>2-8 Wimpern pro natürliche Wimper</li>
    <li>Perfekt für besondere Anlässe</li>
    <li>Mehr Pflegeaufwand</li>
</ul>

<h4>3. Hybrid Lashes</h4>
<p>Eine Mischung aus Classic und Volume für den perfekten <em>natürlich-vollen</em> Look.</p>

<h3>Pflege-Guide für Lash Extensions</h3>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Zeitraum</th>
            <th>Was zu tun ist</th>
            <th>Was zu vermeiden ist</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Erste 24h</strong></td>
            <td>
                <ul>
                    <li>Wimpern trocken halten</li>
                    <li>Nicht berühren</li>
                    <li>Auf dem Rücken schlafen</li>
                </ul>
            </td>
            <td>
                <ul>
                    <li>Duschen/Baden</li>
                    <li>Sauna/Dampfbad</li>
                    <li>Sport/Schwitzen</li>
                </ul>
            </td>
        </tr>
        <tr>
            <td><strong>Dauerhaft</strong></td>
            <td>
                <ul>
                    <li>Sanft mit Wimpernshampoo reinigen</li>
                    <li>Mit Wimpernbürste kämmen</li>
                    <li>Regelmäßige Auffüllung</li>
                </ul>
            </td>
            <td>
                <ul>
                    <li>Öl-basierte Produkte</li>
                    <li>Wasserfeste Mascara</li>
                    <li>Mechanisches Reiben</li>
                </ul>
            </td>
        </tr>
    </tbody>
</table>

<h3>Häufige Fragen</h3>

<h4>💰 Was kosten Lash Extensions?</h4>
<p>Die Preise variieren je nach Technik und Aufwand:</p>
<ul>
    <li><strong>Classic:</strong> 80-120€</li>
    <li><strong>Volume:</strong> 120-180€</li>
    <li><strong>Auffüllung:</strong> 40-80€ (alle 2-3 Wochen)</li>
</ul>

<h4>⏱️ Wie lange dauert die Behandlung?</h4>
<p>Je nach gewünschtem Look:</p>
<ul>
    <li>Classic: 1,5-2 Stunden</li>
    <li>Volume: 2-3 Stunden</li>
    <li>Auffüllung: 45-90 Minuten</li>
</ul>

<blockquote class="blockquote">
    <p>"Perfekte Wimpern sind kein Zufall, sondern das Ergebnis professioneller Arbeit und richtiger Pflege."</p>
    <footer class="blockquote-footer">LK Lashes Expertin Sarah</footer>
</blockquote>

<div class="card bg-light">
    <div class="card-body">
        <h5>🎯 Unser Tipp für Einsteiger</h5>
        <p>Starten Sie mit <strong>Classic Lashes</strong> und probieren Sie nach ein paar Anwendungen Volume aus, wenn Sie einen dramatischeren Look wünschen.</p>
        <a href="/book-appointment/" class="btn btn-primary">Beratungstermin buchen</a>
    </div>
</div>''',
            'is_featured': False
        },
        {
            'title': 'Sommer-Nägel 2024: Farben und Designs für die warme Jahreszeit',
            'slug': 'sommer-naegel-2024-trends',
            'summary': 'Entdecken Sie die angesagtesten Sommerfarben und -designs 2024. Von knalligen Neonfarben bis zu verspielten Tropical Prints.',
            'content': '''<h2>Die Sommer-Trends 2024 sind da!</h2>

<p>Der Sommer 2024 bringt <strong>lebendige Farben</strong> und <em>verspielte Designs</em> mit sich. Lassen Sie sich von unseren Top-Trends inspirieren!</p>

<h3>🌈 Die Trendfarben des Sommers</h3>

<div class="row">
    <div class="col-md-4 mb-3">
        <div class="card text-center" style="border: 3px solid #FF6B6B;">
            <div class="card-body">
                <h5 style="color: #FF6B6B;">Coral Reef</h5>
                <p>Warmes Korallrot für sonnige Tage</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card text-center" style="border: 3px solid #4ECDC4;">
            <div class="card-body">
                <h5 style="color: #4ECDC4;">Ocean Breeze</h5>
                <p>Erfrischendes Türkis wie das Meer</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card text-center" style="border: 3px solid #FFE66D;">
            <div class="card-body">
                <h5 style="color: #FFE66D; text-shadow: 1px 1px 2px black;">Sunshine Yellow</h5>
                <p>Strahlendes Gelb für gute Laune</p>
            </div>
        </div>
    </div>
</div>

<h3>🏝️ Angesagte Design-Trends</h3>

<h4>1. Tropical Vibes</h4>
<p>Bringen Sie das Urlaubsfeeling auf Ihre Nägel:</p>
<ul>
    <li><strong>Palmblätter</strong> in grünen Tönen</li>
    <li><em>Flamingo-Rosa</em> als Akzentfarbe</li>
    <li>Kleine <strong>Ananas-Designs</strong></li>
    <li>Glitzernde <em>Sandeffekte</em></li>
</ul>

<h4>2. Neon Ombré</h4>
<p>Der Farbverlauf in <strong>knalligen Neonfarben</strong> ist perfekt für:</p>
<blockquote>
    <p>"Festivals, Strandpartys und alle, die auffallen möchten!"</p>
</blockquote>

<h4>3. Minimalist Summer</h4>
<p>Für den dezenten Look:</p>
<ol>
    <li>Pastellfarben in <em>Matt-Finish</em></li>
    <li>Einzelne goldene <strong>Akzente</strong></li>
    <li>Negative Space Designs</li>
</ol>

<h3>📅 Sommer-Nagelkalender 2024</h3>

<table class="table table-hover">
    <thead class="table-primary">
        <tr>
            <th>Monat</th>
            <th>Trend</th>
            <th>Must-Have Farbe</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><strong>Juni</strong></td>
            <td>Fresh Pastels</td>
            <td>Mintgrün & Lavendel</td>
        </tr>
        <tr>
            <td><strong>Juli</strong></td>
            <td>Neon Power</td>
            <td>Electric Blue & Neon Pink</td>
        </tr>
        <tr>
            <td><strong>August</strong></td>
            <td>Tropical Paradise</td>
            <td>Coral & Türkis</td>
        </tr>
        <tr>
            <td><strong>September</strong></td>
            <td>Sunset Vibes</td>
            <td>Orange & Gold</td>
        </tr>
    </tbody>
</table>

<div class="alert alert-success">
    <h4>🌟 Profi-Tipp für den Sommer</h4>
    <p>Verwenden Sie einen <strong>UV-Schutz Topcoat</strong> um Ihre Sommerfarben vor dem Ausbleichen zu schützen!</p>
</div>

<h3>DIY vs. Professionell</h3>

<div class="row">
    <div class="col-md-6">
        <h4>🏠 DIY Sommer-Nägel</h4>
        <p><em>Perfekt für:</em></p>
        <ul>
            <li>Einfarbige Designs</li>
            <li>Simple Ombré-Effekte</li>
            <li>Sticker und Aufkleber</li>
        </ul>
        <p><strong>Tipp:</strong> Investieren Sie in gute Pinsel und hochwertige Lacke!</p>
    </div>
    <div class="col-md-6">
        <h4>💅 Profi-Treatment</h4>
        <p><em>Empfohlen für:</em></p>
        <ul>
            <li>Komplexe Nail Art</li>
            <li>Perfekte Farbverläufe</li>
            <li>Lange Haltbarkeit</li>
        </ul>
        <p><strong>Vorteil:</strong> Bis zu 3 Wochen perfekte Nägel!</p>
    </div>
</div>

<h3>Pflege-Tipps für den Sommer</h3>

<p>Die warme Jahreszeit stellt besondere Anforderungen an Ihre <strong>Nagelpflege</strong>:</p>

<div class="card border-warning">
    <div class="card-header bg-warning">
        <h5>☀️ Sommer-Pflege Essentials</h5>
    </div>
    <div class="card-body">
        <ul>
            <li><strong>Sonnenschutz:</strong> UV-Schutz für Hände und Nägel</li>
            <li><strong>Feuchtigkeit:</strong> Nach dem Schwimmen Hände eincremen</li>
            <li><strong>Reinigung:</strong> Sand und Salz gründlich entfernen</li>
            <li><strong>Nachbehandlung:</strong> Alle 2 Wochen zur Auffrischung</li>
        </ul>
    </div>
</div>

<p class="text-center mt-4">
    <a href="/services/" class="btn btn-primary btn-lg me-3">Unsere Sommer-Angebote</a>
    <a href="/gallery/" class="btn btn-outline-primary btn-lg">Inspiration Gallery</a>
</p>''',
            'is_featured': True
        }
    ]

    # Erstelle Blog Posts
    created_count = 0
    updated_count = 0
    
    for post_data in demo_posts:
        post, created = BlogPost.objects.update_or_create(
            slug=post_data['slug'],
            defaults={
                'title': post_data['title'],
                'excerpt': post_data['summary'],
                'content': post_data['content'],
                'content_format': 'html',
                'author': admin_user,
                'is_published': True
            }
        )
        if created:
            created_count += 1
            print(f'Created blog post: {post.title}')
        else:
            updated_count += 1
            print(f'Updated blog post: {post.title}')

    print(f'\nSummary:')
    print(f'- Created: {created_count} new blog posts')
    print(f'- Updated: {updated_count} existing blog posts')
    print(f'- Total: {BlogPost.objects.count()} blog posts in database')
    
    return created_count, updated_count

if __name__ == '__main__':
    create_demo_blogs()