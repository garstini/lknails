#!/usr/bin/env python
import os
import sys
import django
from urllib.request import urlretrieve
import tempfile
from django.core.files import File

# Setup Django
sys.path.append('/Users/copv/Data/code/nails_salon')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nails_salon_project.settings')
django.setup()

from salon.models import Gallery, Service, ServiceCategory

def create_demo_gallery():
    # Placeholder images from unsplash (nails and lashes related)
    demo_images = [
        {
            'title': 'Klassische French Maniküre',
            'description': 'Elegante French Maniküre in zeitlosem Weiß - perfekt für jeden Anlass. Diese klassische Technik verlängert optisch die Finger und sorgt für gepflegte, feminine Hände.',
            'service_name': 'Maniküre ab',
            'is_featured': True,
            'url': 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400&h=400&fit=crop'
        },
        {
            'title': 'Shellac in Rosa Nude',
            'description': 'Zarte Rosa-Nude-Töne mit Shellac Technik für langanhaltenden Glanz. Shellac verbindet die Eigenschaften von Nagellack und Gel - bis zu 2 Wochen perfekte Nägel.',
            'service_name': 'Mit Shellac',
            'is_featured': True,
            'url': 'https://images.unsplash.com/photo-1610992015878-c9b02b70a05f?w=400&h=400&fit=crop'
        },
        {
            'title': 'Glitzer Nail Art Design',
            'description': 'Funkelndes Glitzer-Design für besondere Anlässe. Handgemalte Details und Strasssteine verleihen Ihren Nägeln einen luxuriösen Look.',
            'service_name': 'Maniküre ab',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=400&h=400&fit=crop'
        },
        {
            'title': 'Tropical Summer Nails',
            'description': 'Sommerliche Nail Art mit tropischen Motiven. Palmen, Flamingos und Sonnenuntergänge - holen Sie sich das Urlaubsfeeling auf die Nägel.',
            'service_name': 'Maniküre ab',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=400&h=400&fit=crop'
        },
        {
            'title': 'Wellness Pediküre mit Massage',
            'description': 'Entspannende Pediküre mit wohltuender Fußmassage. Perfekte Pflege für schöne, gesunde Füße mit anschließender Entspannung.',
            'service_name': 'Pediküre mit Massage',
            'is_featured': True,
            'url': 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=400&fit=crop'
        },
        {
            'title': 'Pediküre Shellac in Rot',
            'description': 'Klassischer roter Shellac für die Füße - elegant und langanhaltend. Die perfekte Basis für offene Schuhe und Sommerlooks.',
            'service_name': 'Pediküre mit Shellac inkl. Massage',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1599948010108-4eed07a0e852?w=400&h=400&fit=crop'
        },
        {
            'title': 'Acryl Verlängerung Natural',
            'description': 'Natürliche Acryl-Nagelverlängerung für perfekte Länge. Stabil und langlebig - ideal für alle, die längere Nägel wünschen.',
            'service_name': 'Pediküre mit Acryl inkl. Massage',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1607779097040-26e80aa78e66?w=400&h=400&fit=crop'
        },
        {
            'title': 'Geometrisches Nail Art Design',
            'description': 'Moderne geometrische Muster in schwarz-weiß. Minimalistische Nail Art für den urban-chic Look.',
            'service_name': 'Maniküre ab',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=400&h=400&fit=crop'
        },
        {
            'title': 'Ombré Nails in Pastell',
            'description': 'Sanfter Farbverlauf in zarten Pastelltönen. Ombré-Technik für einen romantischen und verspielten Look.',
            'service_name': 'Mit Shellac',
            'is_featured': True,
            'url': 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400&h=400&fit=crop'
        },
        {
            'title': 'Matte Black Statement',
            'description': 'Elegante matte schwarze Nägel - zeitlos und sophisticated. Der perfekte Look für Business und Abend.',
            'service_name': 'Maniküre ab',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1586696679865-5363c9ccfcc7?w=400&h=400&fit=crop'
        },
        {
            'title': 'Blumen Nail Art Frühling',
            'description': 'Handgemalte Blütenmotive für den Frühling. Zarte Pastellfarben und filigrane Details für einen femininen Look.',
            'service_name': 'Maniküre ab',
            'is_featured': False,
            'url': 'https://images.unsplash.com/photo-1607779097040-26e80aa78e66?w=400&h=400&fit=crop'
        },
        {
            'title': 'Chrome Mirror Finish',
            'description': 'Futuristischer Chrome-Effekt für außergewöhnliche Looks. Spiegelglanz-Finish für alle, die gerne auffallen.',
            'service_name': 'Mit Shellac',
            'is_featured': True,
            'url': 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?w=400&h=400&fit=crop'
        }
    ]
    
    created_count = 0
    
    for demo_data in demo_images:
        # Check if gallery item already exists
        existing = Gallery.objects.filter(title=demo_data['title']).first()
        if existing:
            print(f'Gallery item already exists: {demo_data["title"]}')
            continue
            
        # Find the service
        service = Service.objects.filter(name__icontains=demo_data['service_name']).first()
        
        print(f'Creating gallery item: {demo_data["title"]}')
        
        # For demo purposes, we'll create without actual image files
        # In production, you would download and save actual images
        gallery_item = Gallery.objects.create(
            title=demo_data['title'],
            description=demo_data['description'],
            service=service,
            is_featured=demo_data['is_featured']
        )
        
        created_count += 1
        print(f'Created: {gallery_item.title} (Service: {service.name if service else "None"})')
    
    print(f'\\nSummary:')
    print(f'- Created: {created_count} gallery items')
    print(f'- Total: {Gallery.objects.count()} gallery items in database')
    print(f'- Featured: {Gallery.objects.filter(is_featured=True).count()} featured items')
    
    return created_count

if __name__ == '__main__':
    create_demo_gallery()