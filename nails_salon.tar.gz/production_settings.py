"""
Production settings for VPS deployment
"""

from .nails_salon_project.settings import *
import os

# Override settings for production
DEBUG = False
ALLOWED_HOSTS = ['142.171.70.173', 'lknailslashes.de', 'www.lknailslashes.de', 'localhost']

# Database for production (use PostgreSQL or keep SQLite)
# You can change this to PostgreSQL later if needed
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/var/www/nails_salon/db.sqlite3',
    }
}

# Static files settings for production
STATIC_URL = '/static/'
STATIC_ROOT = '/var/www/nails_salon/staticfiles/'

# Media files settings for production  
MEDIA_URL = '/media/'
MEDIA_ROOT = '/var/www/nails_salon/media/'

# Security settings for production
SECURE_SSL_REDIRECT = False  # Set to True when you have SSL
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

# Session security
SESSION_COOKIE_SECURE = False  # Set to True when you have SSL
CSRF_COOKIE_SECURE = False     # Set to True when you have SSL

# Email settings remain using the database configuration
EMAIL_BACKEND = 'salon.email_backends.DynamicEmailBackend'

# Logging configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': '/var/www/nails_salon/logs/django.log',
        },
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file', 'console'],
            'level': 'INFO',
            'propagate': True,
        },
        'salon': {
            'handlers': ['file', 'console'],
            'level': 'INFO',
            'propagate': True,
        },
    },
}

# Cache configuration (optional)
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'nails-salon-cache',
    }
}