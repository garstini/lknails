#!/bin/bash

# Deployment script for VPS
echo "Starting deployment to VPS..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

VPS_HOST="142.171.70.173"
VPS_USER="root"
PROJECT_NAME="nails_salon"
VPS_PATH="/var/www/${PROJECT_NAME}"

echo -e "${YELLOW}Creating deployment package...${NC}"

# Create deployment directory
mkdir -p deploy_package
cd deploy_package

# Copy project files (excluding development files)
rsync -av --exclude='__pycache__' --exclude='*.pyc' --exclude='.git' --exclude='venv' --exclude='env' --exclude='deploy_package' --exclude='db.sqlite3' ../ ./

# Copy production settings
cp ../production_settings.py ./

echo -e "${GREEN}Package created successfully!${NC}"

echo -e "${YELLOW}Uploading to VPS...${NC}"

# Create project directory on VPS
ssh ${VPS_USER}@${VPS_HOST} "mkdir -p ${VPS_PATH}"
ssh ${VPS_USER}@${VPS_HOST} "mkdir -p ${VPS_PATH}/logs"
ssh ${VPS_USER}@${VPS_HOST} "mkdir -p ${VPS_PATH}/staticfiles"
ssh ${VPS_USER}@${VPS_HOST} "mkdir -p ${VPS_PATH}/media"

# Upload files to VPS
rsync -avz --delete ./ ${VPS_USER}@${VPS_HOST}:${VPS_PATH}/

echo -e "${GREEN}Files uploaded successfully!${NC}"

echo -e "${YELLOW}Setting up environment on VPS...${NC}"

# Install dependencies and setup on VPS
ssh ${VPS_USER}@${VPS_HOST} << 'EOF'
cd /var/www/nails_salon

# Install Python3 and pip if not installed
apt update
apt install -y python3 python3-pip python3-venv nginx supervisor

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt
pip install gunicorn

# Install additional required packages
pip install psycopg2-binary  # For PostgreSQL support if needed later

# Collect static files
export DJANGO_SETTINGS_MODULE=production_settings
python manage.py collectstatic --noinput

# Run migrations
python manage.py migrate

# Create superuser (skip if exists)
python manage.py shell -c "
from django.contrib.auth.models import User
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@lknails.de', 'admin123')
    print('Superuser created: admin/admin123')
else:
    print('Superuser already exists')
"

# Compile messages
python manage.py compilemessages

# Set permissions
chown -R www-data:www-data /var/www/nails_salon
chmod -R 755 /var/www/nails_salon

EOF

echo -e "${GREEN}Environment setup completed!${NC}"

echo -e "${YELLOW}Configuring Nginx and Supervisor...${NC}"

# Create Nginx configuration
ssh ${VPS_USER}@${VPS_HOST} << 'EOF'
cat > /etc/nginx/sites-available/nails_salon << 'NGINX_CONFIG'
server {
    listen 80;
    server_name 142.171.70.173 lknailslashes.de www.lknailslashes.de;

    # Serve static files
    location /static/ {
        alias /var/www/nails_salon/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    # Serve media files
    location /media/ {
        alias /var/www/nails_salon/media/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }

    # Proxy to Django application
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
NGINX_CONFIG

# Enable the site
ln -sf /etc/nginx/sites-available/nails_salon /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t

EOF

# Create Supervisor configuration for Gunicorn
ssh ${VPS_USER}@${VPS_HOST} << 'EOF'
cat > /etc/supervisor/conf.d/nails_salon.conf << 'SUPERVISOR_CONFIG'
[program:nails_salon]
command=/var/www/nails_salon/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 nails_salon_project.wsgi:application
directory=/var/www/nails_salon
user=www-data
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/www/nails_salon/logs/gunicorn.log
environment=DJANGO_SETTINGS_MODULE=production_settings
SUPERVISOR_CONFIG

# Restart services
supervisorctl reread
supervisorctl update
supervisorctl start nails_salon
systemctl restart nginx

EOF

echo -e "${GREEN}Deployment completed successfully!${NC}"
echo -e "${YELLOW}Your Django application is now running at: http://142.171.70.173${NC}"
echo -e "${YELLOW}Admin panel: http://142.171.70.173/admin${NC}"
echo -e "${YELLOW}Default admin credentials: admin/admin123${NC}"

# Clean up
cd ..
rm -rf deploy_package

echo -e "${GREEN}Deployment package cleaned up.${NC}"